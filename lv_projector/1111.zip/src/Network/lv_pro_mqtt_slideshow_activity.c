/**
 * @file lv_pro_mqtt_slideshow_activity.c
 * @brief MQTT-based image slideshow using libmosquitto (for OpenWrt)
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <time.h>
#include <signal.h>
#include <dirent.h>
#include <curl/curl.h>
#include <mosquitto.h>
#include "cJSON.h"
#include "lv_pro_mqtt_slideshow_activity.h"

#define LOG_FILE_PATH "/tmp/lv_projector.log"
#define MAX_LOG_SIZE 10240  // Maximum 10KB of log to send

// Global variables
// [修改1] 删除默认值 "101"，初始化为空字符串
static char current_template[100] = {0};
static char image_urls[MAX_IMAGES][256] = {0};
static int image_count = 0;
static pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;
static bool slideshow_running = false;
static char mqtt_topic[128] = {0};
static char device_snum[64] = {0};

// MQTT client
static struct mosquitto *mosq = NULL;
static pthread_t mqtt_thread_id;
static pthread_t heartbeat_thread_id;
static bool heartbeat_running = false;

// LVGL objects
lv_obj_t *mqtt_slideshow_activity = NULL;
lv_obj_t *mqtt_slideshow_img = NULL;
lv_group_t *mqtt_slideshow_group = NULL;
static lv_obj_t *status_label = NULL;
static lv_timer_t *slideshow_timer = NULL;
static int current_image_index = 0;

// Flag to indicate new images are ready to display
static bool new_images_ready = false;
static bool download_in_progress = false;

// Forward declarations
static void process_template_json(const char *template_list_str);
static void send_error_log_to_mqtt(const char *error_msg);
static void signal_handler(int sig);
static void *mqtt_listener_thread(void *arg);
static void slideshow_timer_cb(lv_timer_t *timer);
static void save_current_index(void);
static int load_last_index(void);
static void scan_local_images(void); // [新增] 扫描本地图片函数声明

// ... (send_error_log_to_mqtt 保持不变) ...
static void send_error_log_to_mqtt(const char *error_msg) {
    if (mosq == NULL || device_snum[0] == '\0') return;
    FILE *log_file = fopen(LOG_FILE_PATH, "r");
    if (!log_file) return;
    fseek(log_file, 0, SEEK_END);
    long file_size = ftell(log_file);
    long read_size = file_size > MAX_LOG_SIZE ? MAX_LOG_SIZE : file_size;
    fseek(log_file, file_size - read_size, SEEK_SET);
    char log_content[MAX_LOG_SIZE + 1] = {0};
    fread(log_content, 1, read_size, log_file);
    fclose(log_file);
    cJSON *root = cJSON_CreateObject();
    cJSON_AddStringToObject(root, "sn", device_snum);
    cJSON_AddStringToObject(root, "error", error_msg);
    cJSON_AddStringToObject(root, "log", log_content);
    cJSON_AddNumberToObject(root, "timestamp", (double)time(NULL));
    char *json_str = cJSON_PrintUnformatted(root);
    if (json_str) {
        mosquitto_publish(mosq, NULL, "log_error", strlen(json_str), json_str, 1, false);
        free(json_str);
    }
    cJSON_Delete(root);
}

// ... (signal_handler 保持不变) ...
static void signal_handler(int sig) {
    const char *sig_name = "Unknown";
    switch (sig) {
        case SIGSEGV: sig_name = "SIGSEGV"; break;
        case SIGABRT: sig_name = "SIGABRT"; break;
        case SIGFPE: sig_name = "SIGFPE"; break;
        case SIGILL: sig_name = "SIGILL"; break;
        case SIGBUS: sig_name = "SIGBUS"; break;
    }
    char error_msg[256];
    snprintf(error_msg, sizeof(error_msg), "Program crashed with signal %d: %s", sig, sig_name);
    fprintf(stderr, "\n[FATAL] %s\n", error_msg);
    send_error_log_to_mqtt(error_msg);
    sleep(2);
    exit(sig);
}

// ... (save_current_index, load_last_index 保持不变) ...
static void save_current_index(void) {
    FILE *fp = fopen(STATE_FILE, "w");
    if (fp) {
        fprintf(fp, "%d", current_image_index);
        fclose(fp);
    }
}

static int load_last_index(void) {
    FILE *fp = fopen(STATE_FILE, "r");
    if (!fp) return 0;
    int index = 0;
    if (fscanf(fp, "%d", &index) != 1) index = 0;
    fclose(fp);
    return index;
}

// ... (write_callback, download_file 保持不变) ...
static size_t write_callback(void *contents, size_t size, size_t nmemb, void *userp) {
    size_t realsize = size * nmemb;
    char *data = (char *)userp;
    if (strlen(data) + realsize >= 4096) return 0;
    strncat(data, contents, realsize);
    return realsize;
}

static int download_file(const char *url, const char *filename) {
    // (保持原有代码逻辑不变，这里省略以节省篇幅，请保留原有的 download_file 实现)
    // ...
    CURL *curl = curl_easy_init();
    if (!curl) return -1;
    FILE *fp = fopen(filename, "wb");
    if (!fp) { curl_easy_cleanup(curl); return -2; }
    curl_easy_setopt(curl, CURLOPT_URL, url);
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, NULL);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, fp);
    curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
    curl_easy_setopt(curl, CURLOPT_TIMEOUT, 15L);
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 0L);
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 0L);
    CURLcode res = curl_easy_perform(curl);
    fclose(fp);
    curl_easy_cleanup(curl);
    if (res != CURLE_OK) return -3;
    return 0;
}

// ... (fetch_images_from_json 保持不变) ...
static int fetch_images_from_json(const char *template_id, char temp_urls[][256], int *temp_count) {
    // (保持原有代码逻辑不变)
    char url[512];
    char response[4096] = {0};
    snprintf(url, sizeof(url), HTTP_TEMPLATE_URL, template_id);
    printf("[MQTT Slideshow] Requesting template: %s\n", url);
    
    CURL *curl = curl_easy_init();
    if (!curl) return -1;
    curl_easy_setopt(curl, CURLOPT_URL, url);
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, write_callback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, response);
    curl_easy_setopt(curl, CURLOPT_TIMEOUT, 10L);
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 0L);
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 0L);
    CURLcode res = curl_easy_perform(curl);
    long response_code = 0;
    curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &response_code);
    curl_easy_cleanup(curl);

    if (res != CURLE_OK || response_code >= 400) return -2;

    cJSON *root = cJSON_Parse(response);
    if (!root) return -4;
    
    // 解析逻辑保持不变...
    cJSON *data_obj = cJSON_GetObjectItem(root, "data");
    if (cJSON_IsObject(data_obj)) {
        cJSON *options_str = cJSON_GetObjectItem(data_obj, "options");
        if (cJSON_IsString(options_str)) {
            cJSON *options_obj = cJSON_Parse(cJSON_GetStringValue(options_str));
            if (options_obj) {
                cJSON *image_array = cJSON_GetObjectItem(options_obj, "image");
                if (cJSON_IsArray(image_array)) {
                    cJSON *image_item;
                    cJSON_ArrayForEach(image_item, image_array) {
                        if (*temp_count >= MAX_IMAGES) break;
                        cJSON *url_obj = cJSON_GetObjectItem(image_item, "url");
                        if (cJSON_IsString(url_obj) && strlen(cJSON_GetStringValue(url_obj)) > 0) {
                            snprintf(temp_urls[*temp_count], 256, "%s", cJSON_GetStringValue(url_obj));
                            (*temp_count)++;
                        }
                    }
                }
                cJSON_Delete(options_obj);
            }
        }
    }
    cJSON_Delete(root);
    return 0;
}

// ... (clear_old_images 保持不变) ...
static void clear_old_images(void) {
    DIR *dir = opendir(IMAGE_DIR);
    if (!dir) return;
    struct dirent *entry;
    while ((entry = readdir(dir)) != NULL) {
        if (strcmp(entry->d_name, ".") == 0 || strcmp(entry->d_name, "..") == 0) continue;
        if (strcmp(entry->d_name, "slideshow_state.txt") == 0) continue;
        if (strstr(entry->d_name, ".jpg") || strstr(entry->d_name, ".png")) {
            char filepath[512];
            snprintf(filepath, sizeof(filepath), "%s%s", IMAGE_DIR, entry->d_name);
            remove(filepath);
        }
    }
    closedir(dir);
}

// ... (process_template_json 保持不变) ...
static void process_template_json(const char *template_list_str) {
    // (保持原有逻辑：解析逗号分隔的列表，获取URL，下载图片)
    printf("[MQTT Slideshow] Processing template list: %s\n", template_list_str);
    char temp_urls[MAX_IMAGES][256] = {0};
    int temp_count = 0;
    char list_copy[100];
    strncpy(list_copy, template_list_str, sizeof(list_copy) - 1);
    list_copy[sizeof(list_copy) - 1] = '\0';
    char *token = strtok(list_copy, ",");
    int request_failed = 0;

    while (token != NULL && !request_failed) {
        char *id = token;
        while (*id == ' ') id++;
        if (strlen(id) > 0) {
            if (fetch_images_from_json(id, temp_urls, &temp_count) != 0) {
                request_failed = 1;
            }
        }
        token = strtok(NULL, ",");
    }

    if (request_failed) return;

    pthread_mutex_lock(&lock);
    download_in_progress = true;
    image_count = 0;
    for (int i = 0; i < MAX_IMAGES; i++) image_urls[i][0] = '\0';
    pthread_mutex_unlock(&lock);

    clear_old_images();

    struct timeval tv;
    gettimeofday(&tv, NULL);
    long long timestamp_base = tv.tv_sec * 1000LL + tv.tv_usec / 1000;
    int new_count = 0;
    char new_urls[MAX_IMAGES][256] = {0};

    for (int i = 0; i < temp_count && i < MAX_IMAGES; i++) {
        char filename[256];
        snprintf(filename, sizeof(filename), "%s%lld_%d.jpg", IMAGE_DIR, timestamp_base, i);
        if (download_file(temp_urls[i], filename) == 0) {
            snprintf(new_urls[i], sizeof(new_urls[i]), "A:%s", filename);
            new_count++;
        }
    }

    pthread_mutex_lock(&lock);
    for (int i = 0; i < new_count; i++) {
        snprintf(image_urls[i], sizeof(image_urls[i]), "%s", new_urls[i]);
    }
    image_count = new_count;
    current_image_index = -1; // Reset to start
    download_in_progress = false;
    new_images_ready = true;
    pthread_mutex_unlock(&lock);
}

// ... (on_message 保持不变) ...
static void on_message(struct mosquitto *mosq, void *userdata, const struct mosquitto_message *message) {
    if (message->payloadlen >= sizeof(current_template)) return;
    strncpy(current_template, message->payload, message->payloadlen);
    current_template[message->payloadlen] = '\0';
    
    char *end = current_template + strlen(current_template) - 1;
    while (end > current_template && (*end == '\n' || *end == '\r' || *end == ' ')) {
        *end = '\0'; end--;
    }
    printf("[MQTT Slideshow] Received MQTT message [%s]: %s\n", message->topic, current_template);
    if (strcmp(message->topic, mqtt_topic) == 0) {
        process_template_json(current_template);
    }
}

// [修改2] 修改 on_connect，删除自动请求默认模板的逻辑
static void on_connect(struct mosquitto *mosq, void *userdata, int result) {
    if (result == 0) {
        printf("[MQTT Slideshow] Connected to MQTT broker\n");
        mosquitto_subscribe(mosq, NULL, mqtt_topic, 1);
        printf("[MQTT Slideshow] Subscribed to topic: %s\n", mqtt_topic);
        
        // [修改] 只有当 current_template 不为空时（即运行时接收到了新指令），才在重连时重新处理
        // 开机时 current_template 初始化为 {0}，所以不会触发这里的下载
        if (strlen(current_template) > 0) {
            printf("[MQTT Slideshow] Reconnected, re-processing last known template: %s\n", current_template);
            process_template_json(current_template);
        }
    } else {
        fprintf(stderr, "[MQTT Slideshow] Connect failed: %s\n", mosquitto_connack_string(result));
    }
}

// ... (on_disconnect, mqtt_heartbeat_thread 保持不变) ...
static void on_disconnect(struct mosquitto *mosq, void *userdata, int rc) {
    if (rc != 0) fprintf(stderr, "[MQTT Slideshow] Disconnected unexpectedly (rc=%d)\n", rc);
}

static void *mqtt_heartbeat_thread(void *arg) {
    while (heartbeat_running) {
        sleep(30);
        if (!heartbeat_running) break;
        if (mosq != NULL) {
            char payload[128];
            snprintf(payload, sizeof(payload), "{\"sn\":\"%s\"}", device_snum);
            mosquitto_publish(mosq, NULL, "device_heartbeat", strlen(payload), payload, 1, false);
        }
    }
    return NULL;
}

// ... (mqtt_listener_thread 逻辑基本不变，除了移除 on_connect 后立即调用的逻辑) ...
static void *mqtt_listener_thread(void *arg) {
    const char *snum = getenv("snum");
    if (snum && strlen(snum) > 0) {
        snprintf(device_snum, sizeof(device_snum), "%s", snum);
        snprintf(mqtt_topic, sizeof(mqtt_topic), "update_device_template/%s", device_snum);
    } else {
        snprintf(device_snum, sizeof(device_snum), "88888888");
        snprintf(mqtt_topic, sizeof(mqtt_topic), "%s", MQTT_TOPIC);
    }

    mosquitto_lib_init();
    char client_id[128];
    snprintf(client_id, sizeof(client_id), "LVGL_ImageDisplay_%s", device_snum);
    mosq = mosquitto_new(client_id, true, NULL);
    if (!mosq) return NULL;

    mosquitto_connect_callback_set(mosq, on_connect);
    mosquitto_message_callback_set(mosq, on_message);
    mosquitto_disconnect_callback_set(mosq, on_disconnect);
    mosquitto_username_pw_set(mosq, MQTT_USERNAME, MQTT_PASSWORD);
    mosquitto_reconnect_delay_set(mosq, 1, 30, true);

    char broker_host[256];
    int broker_port = 1883;
    const char *broker_str = MQTT_BROKER_TCP;
    if (strncmp(broker_str, "tcp://", 6) == 0) broker_str += 6;
    sscanf(broker_str, "%255[^:]:%d", broker_host, &broker_port);

    int rc = mosquitto_connect(mosq, broker_host, broker_port, 30);
    
    heartbeat_running = true;
    pthread_create(&heartbeat_thread_id, NULL, mqtt_heartbeat_thread, NULL);

    // [修改] 移除这里原本的 process_template_json(current_template) 调用
    // 因为我们希望开机显示本地图片，而不是去下载 "101"

    mosquitto_loop_forever(mosq, -1, 1);

    heartbeat_running = false;
    pthread_join(heartbeat_thread_id, NULL);
    mosquitto_destroy(mosq);
    mosquitto_lib_cleanup();
    mosq = NULL;
    return NULL;
}

// [新增] qsort 的比较函数，用于对文件名进行排序
static int compare_filenames(const void *a, const void *b) {
    return strcmp(*(const char **)a, *(const char **)b);
}

// [新增] 扫描本地目录并加载图片
static void scan_local_images(void) {
    printf("[MQTT Slideshow] Scanning local images in %s\n", IMAGE_DIR);
    
    DIR *dir = opendir(IMAGE_DIR);
    if (!dir) {
        printf("[MQTT Slideshow] Image directory does not exist yet.\n");
        return;
    }

    char *temp_files[MAX_IMAGES];
    int count = 0;
    struct dirent *entry;

    // 1. 读取所有有效图片文件名
    while ((entry = readdir(dir)) != NULL) {
        if (strstr(entry->d_name, ".jpg") || strstr(entry->d_name, ".jpeg") ||
            strstr(entry->d_name, ".png") || strstr(entry->d_name, ".bmp")) {
            
            if (count < MAX_IMAGES) {
                temp_files[count] = strdup(entry->d_name); // 复制文件名
                count++;
            }
        }
    }
    closedir(dir);

    if (count == 0) {
        printf("[MQTT Slideshow] No local images found.\n");
        return;
    }

    // 2. 排序 (确保按时间戳/名称顺序播放)
    qsort(temp_files, count, sizeof(char *), compare_filenames);

    // 3. 更新全局变量
    pthread_mutex_lock(&lock);
    image_count = 0;
    for (int i = 0; i < count; i++) {
        // 构建 LVGL 路径 (A:/var/mqtt_images/filename)
        snprintf(image_urls[i], sizeof(image_urls[i]), "A:%s%s", IMAGE_DIR, temp_files[i]);
        printf("[MQTT Slideshow] Loaded local image: %s\n", image_urls[i]);
        free(temp_files[i]); // 释放 strdup 分配的内存
    }
    image_count = count;
    pthread_mutex_unlock(&lock);

    printf("[MQTT Slideshow] Local scan complete. Found %d images.\n", image_count);
}

// ... (slideshow_timer_cb 保持不变) ...
static void slideshow_timer_cb(lv_timer_t *timer) {
    pthread_mutex_lock(&lock);

    if (download_in_progress) {
        pthread_mutex_unlock(&lock);
        return;
    }

    if (new_images_ready) {
        new_images_ready = false;
        lv_img_cache_set_size(0);
        lv_img_cache_set_size(LV_IMG_CACHE_DEF_SIZE);

        if (mqtt_slideshow_img != NULL && image_count > 0) {
            int resume_index = load_last_index();
            // 如果之前存的索引超出了当前图片数量，重置为0
            if (resume_index < 0 || resume_index >= image_count) {
                resume_index = 0;
            }
            current_image_index = resume_index;

            lv_img_set_src(mqtt_slideshow_img, NULL);
            lv_img_set_src(mqtt_slideshow_img, image_urls[current_image_index]);
            printf("[MQTT Slideshow] Start/Resume showing image %d/%d: %s\n",
                   current_image_index + 1, image_count, image_urls[current_image_index]);
            save_current_index();
        }
        pthread_mutex_unlock(&lock);
        return;
    }

    if (image_count == 0) {
        pthread_mutex_unlock(&lock);
        return;
    }

    // 正常轮播逻辑
    current_image_index = (current_image_index + 1) % image_count;

    if (mqtt_slideshow_img != NULL && image_urls[current_image_index][0] != '\0') {
        lv_img_set_src(mqtt_slideshow_img, NULL);
        lv_img_set_src(mqtt_slideshow_img, image_urls[current_image_index]);
        printf("[MQTT Slideshow] Showing image %d/%d: %s\n",
               current_image_index + 1, image_count, image_urls[current_image_index]);
    }

    save_current_index();
    pthread_mutex_unlock(&lock);
}

/**
 * @brief Initialize MQTT slideshow UI
 */
void lv_pro_mqtt_slideshow_ui_init(void) {
    setvbuf(stdout, NULL, _IOLBF, 0);
    setvbuf(stderr, NULL, _IOLBF, 0);

    signal(SIGSEGV, signal_handler);
    signal(SIGABRT, signal_handler);
    // ... 其他信号 ...

    curl_global_init(CURL_GLOBAL_DEFAULT);
    mkdir(IMAGE_DIR, 0755);

    mqtt_slideshow_activity = lv_obj_create(lv_scr_act());
    lv_obj_set_size(mqtt_slideshow_activity, LV_HOR_RES, LV_VER_RES);
    lv_obj_set_style_bg_color(mqtt_slideshow_activity, lv_color_white(), 0);
    lv_obj_clear_flag(mqtt_slideshow_activity, LV_OBJ_FLAG_SCROLLABLE);

    mqtt_slideshow_img = lv_img_create(mqtt_slideshow_activity);
    lv_obj_center(mqtt_slideshow_img);
    lv_obj_set_style_img_recolor_opa(mqtt_slideshow_img, 0, 0);

    // [修改3] 删除硬编码的 photo.jpg 设置
    // lv_img_set_src(mqtt_slideshow_img, "A:/usr/share/lv_projector/photo.jpg");
    
    // [新增] 开机立即扫描本地图片目录
    scan_local_images();

    // [新增] 如果本地有图片，立即显示上一张（或第一张）
    if (image_count > 0) {
        int last_index = load_last_index();
        if (last_index >= 0 && last_index < image_count) {
            current_image_index = last_index;
        } else {
            current_image_index = 0;
        }
        
        // 立即设置图片源，无需等待定时器第一次回调
        lv_img_set_src(mqtt_slideshow_img, image_urls[current_image_index]);
        printf("[MQTT Slideshow] Boot: Resumed from image %d/%d: %s\n", 
               current_image_index + 1, image_count, image_urls[current_image_index]);
    } else {
        printf("[MQTT Slideshow] Boot: No local images found, waiting for MQTT...\n");
        // 可以选择显示一个空白图或者等待图标，或者保持背景色
    }

    mqtt_slideshow_group = lv_group_create();

    // 启动定时器
    slideshow_timer = lv_timer_create(slideshow_timer_cb, SLIDESHOW_INTERVAL, NULL);
    
    printf("[MQTT Slideshow] UI initialized.\n");
}

// ... (start, stop, exit 函数保持不变) ...
void lv_pro_mqtt_slideshow_start(void) {
    if (slideshow_running) return;
    slideshow_running = true;
    if (pthread_create(&mqtt_thread_id, NULL, mqtt_listener_thread, NULL) != 0) {
        slideshow_running = false;
        return;
    }
}

void lv_pro_mqtt_slideshow_stop(void) {
    if (!slideshow_running) return;
    slideshow_running = false;
    heartbeat_running = false;
    if (heartbeat_thread_id != 0) {
        pthread_join(heartbeat_thread_id, NULL);
        heartbeat_thread_id = 0;
    }
    if (slideshow_timer != NULL) lv_timer_pause(slideshow_timer);
    if (mosq != NULL) {
        mosquitto_disconnect(mosq);
        mosquitto_destroy(mosq);
        mosq = NULL;
    }
}

void lv_pro_mqtt_slideshow_exit(void) {
    lv_pro_mqtt_slideshow_stop();
    if (mosq != NULL) {
        mosquitto_destroy(mosq);
        mosquitto_lib_cleanup();
        mosq = NULL;
    }
    if (mqtt_thread_id) pthread_join(mqtt_thread_id, NULL);
    if (slideshow_timer != NULL) {
        lv_timer_del(slideshow_timer);
        slideshow_timer = NULL;
    }
    if (mqtt_slideshow_activity != NULL) {
        lv_obj_del(mqtt_slideshow_activity);
        mqtt_slideshow_activity = NULL;
    }
    if (mqtt_slideshow_group != NULL) {
        lv_group_del(mqtt_slideshow_group);
        mqtt_slideshow_group = NULL;
    }
    pthread_mutex_destroy(&lock);
    curl_global_cleanup();
}

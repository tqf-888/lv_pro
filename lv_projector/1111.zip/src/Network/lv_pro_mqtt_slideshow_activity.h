/**
 * @file lv_pro_mqtt_slideshow_activity.h
 * @brief MQTT-based image slideshow activity header
 *
 * This module implements an MQTT-driven image slideshow that:
 * - Subscribes to MQTT topic for template ID updates
 * - Fetches image URLs from HTTP API based on template ID
 * - Downloads images using libcurl
 * - Displays images in a slideshow using LVGL
 */

#ifndef LV_PRO_MQTT_SLIDESHOW_ACTIVITY_H
#define LV_PRO_MQTT_SLIDESHOW_ACTIVITY_H

#include "lvgl/lvgl.h"

// Configuration
#define MQTT_BROKER_TCP "tcp://120.27.199.92:1883"
#define MQTT_BROKER_WS "ws://120.27.199.92:8083"
#define MQTT_TOPIC "update_device_template/88888888"
#define MQTT_USERNAME "chongwu_emqx_mqtt"
#define MQTT_PASSWORD "chongwu_emqx_mqtt@2025"
#define HTTP_TEMPLATE_URL "http://112.74.32.81:30008/template/%s"
#define IMAGE_DIR "/root/mqtt_images/"
#define STATE_FILE "/root/mqtt_images/slideshow_state.txt"
#define MAX_IMAGES 10
#define SLIDESHOW_INTERVAL 3000  // 3 seconds per image

// External objects
extern lv_obj_t *mqtt_slideshow_activity;
extern lv_obj_t *mqtt_slideshow_img;
extern lv_group_t *mqtt_slideshow_group;

/**
 * @brief Initialize MQTT slideshow UI
 * Creates the LVGL UI components and starts MQTT connection
 */
void lv_pro_mqtt_slideshow_ui_init(void);

/**
 * @brief Exit and cleanup MQTT slideshow activity
 * Stops MQTT connection, cleans up resources
 */
void lv_pro_mqtt_slideshow_exit(void);

/**
 * @brief Start MQTT slideshow
 * Begins the image slideshow and MQTT listening
 */
void lv_pro_mqtt_slideshow_start(void);

/**
 * @brief Stop MQTT slideshow
 * Pauses the slideshow
 */
void lv_pro_mqtt_slideshow_stop(void);

#endif  /* LV_PRO_MQTT_SLIDESHOW_ACTIVITY_H */

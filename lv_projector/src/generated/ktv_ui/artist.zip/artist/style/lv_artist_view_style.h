#ifndef LV_ARTIST_VIEW_STYLE_H
#define LV_ARTIST_VIEW_STYLE_H

#ifdef __cplusplus
extern "C" {
#endif

#include "lvgl/lvgl.h"

typedef struct {
    lv_coord_t cell_width;
    lv_coord_t cell_height;

    lv_coord_t avatar_x;
    lv_coord_t avatar_y;
    lv_coord_t avatar_w;
    lv_coord_t avatar_h;

    lv_coord_t name_x;
    lv_coord_t name_y;
    lv_coord_t name_w;

    lv_color_t bg_color;
    lv_opa_t bg_opa;
    lv_color_t border_color;
    uint8_t border_width;
    lv_coord_t radius;

    lv_color_t avatar_bg_color;
    lv_opa_t avatar_bg_opa;
    lv_coord_t avatar_radius;

    lv_color_t checked_bg_color;
    lv_opa_t checked_bg_opa;

    const lv_font_t *name_font;
    lv_color_t name_color;
    lv_opa_t name_opa;

    const lv_font_t *placeholder_font;
    lv_color_t placeholder_color;
    lv_opa_t placeholder_opa;
} lv_artist_row_style_t;

typedef struct {
    uint32_t visible_rows;
    uint32_t visible_cols;
    uint32_t overscan_rows_front;
    uint32_t overscan_rows_back;
    uint32_t preload_before;
    uint32_t preload_after;

    lv_coord_t viewport_width;
    lv_coord_t viewport_height;
    lv_coord_t cell_width;
    lv_coord_t cell_height;
    lv_coord_t gap_x;
    lv_coord_t gap_y;

    lv_artist_row_style_t row_style;
} lv_artist_view_style_t;

extern lv_artist_view_style_t g_lv_artist_default_style;
void lv_artist_default_style_init(void);

#ifdef __cplusplus
}
#endif

#endif
